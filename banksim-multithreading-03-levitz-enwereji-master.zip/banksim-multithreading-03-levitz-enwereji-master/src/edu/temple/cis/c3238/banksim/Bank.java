package edu.temple.cis.c3238.banksim;

/**
 * @author Cay Horstmann
 * @author Modified by Paul Wolfgang
 * @author Modified by Charles Wang
 * @author Modified by Alexa Delacenserie
 * @author Modified by Tarek Elseify
 */

public class Bank {

    public static final int NTEST = 10;
    private final Account[] accounts;
    private long numTransactions = 0;
    public final int initialBalance;
    private final int numAccounts;
    private boolean testVal = true;
    private boolean d_cond;

    public Bank(int numAccounts, int initialBalance) {
        this.initialBalance = initialBalance;
        this.numAccounts = numAccounts;
        accounts = new Account[numAccounts];
        for (int i = 0; i < accounts.length; i++) {
            accounts[i] = new Account(i, initialBalance);
        }
        numTransactions = 0;
    }

    public synchronized void transfer(int from, int to, int amount) throws InterruptedException {
        //accounts[from].waitForAvailableFunds(amount);
        synchronized(this){
		if(d_cond == false){
			return; // this should stop the proceeding?
		}
		while(accounts[from].getBalance() < amount){
			wait();
		}
		if(accounts[from].withdraw(amount)) {
			accounts[to].deposit(amount);
		}

		numTransactions++;
		notifyAll();

        }


        // Uncomment line when race condition in test() is fixed.
        if (shouldTest()) {
	        synchronized(this){
		        while(!testVal){
			        try{
				        wait();
			        }catch(InterruptedException e){
				        Thread.currentThread().interrupt();
			        }
		        }
	            testVal = false;
	            notifyAll();
	        }
        }
        test();
    }
	
    public void openBank(){
        synchronized(this){
            d_cond = true;
            synchronized(this){
                notifyAll();
            }
        }
    }
    
    public void closeBank(){
        synchronized(this){
            d_cond = false;
            synchronized(this){
                notifyAll();
            }
        }
    }

    public synchronized void test() {
        int totalBalance = 0;
        for (Account account : accounts) {
            System.out.printf("%-30s %s%n", 
                    Thread.currentThread().toString(), account.toString());
            totalBalance += account.getBalance();
        }
        System.out.printf("%-30s Total balance: %d\n", Thread.currentThread().toString(), totalBalance);
        if (totalBalance != numAccounts * initialBalance) {
            System.out.printf("%-30s Total balance changed!\n", Thread.currentThread().toString());
            System.exit(0);
        } else {
            System.out.printf("%-30s Total balance unchanged.\n", Thread.currentThread().toString());
        }
    }

    public int getNumAccounts() {
        return numAccounts;
    }
    
    
    public boolean shouldTest() {
        return ++numTransactions % NTEST == 0;
    }

}
