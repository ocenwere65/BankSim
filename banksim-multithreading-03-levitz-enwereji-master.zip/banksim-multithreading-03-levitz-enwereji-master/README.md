For this project, we were required to modify existing code that would resolve race conditions and deadlocks. Each member completed task 1, constructing a UML sequence diagram; For the following tasks, we alternated between each succeeding task, with Collins Enwereji handling tasks 3 and 5 and Kevin Levitz handling tasks 2 and 4.

For Task 2 Kevin added a sycronized block for the transfer method within bank.
For Task 4 Kevin added a wait() call for transfer method to wait until the account has the correct balance to transfer.

For task 3, Collins integrated a synchronized lock in the transfer() method (in Bank implementation) to resolve the race condition between the threads of each account. For task 5, Collins developed two function: openBank() and closedBank(), and code a function call in the accounts file to resolve a deadlock condition.

In terms of collaboration, we designed a schedule to equally distribute the technical portions of this project. We designed the UML sequence diagram in a shared google draw.io file.	 We than alternated between the succeeding tasks, in terms of programming the solution and testing. We also interchange texts to voice feedback, whether it be haring updates on the project (pull requests), suggestions on how to improve, or clearing miscommunications.

Manual testing based on expected results. Kevin discovered the race condition via testing in the beginning. Collins tested the synchronized locks to ensure the project yielded accurate results.
